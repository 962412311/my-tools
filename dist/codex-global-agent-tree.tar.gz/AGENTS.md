@$HOME/.codex/BOOTSTRAP.md
